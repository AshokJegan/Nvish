from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/ping', methods=['GET'])
def get_ping():
    res_data = {"message": 'Ping'}
    return jsonify(res_data)

if __name__ == "__main__":
    app.run(port=8000)
