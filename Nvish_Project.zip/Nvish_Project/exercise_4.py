from flask import Flask, request, jsonify
from flask_caching import Cache
from db import dbconnect
import sqlite3

app= Flask(__name__)
cache = Cache(app)

@app.route('/save_val', methods=['POST'])
def save_val():
    data = request.json
    key = data.get('Employee_Name')
    value = data.get('Employee_Id')
    if key is None or value is None:
        return 'Both key and value are required'

    try:        
        conn = dbconnect()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO data (Employee_Name, Employee_Id) VALUES (?, ?)', (key, value))
        conn.commit()
        cache.delete(key)
        return 'Data saved successfully'
    except sqlite3.IntegrityError:
        return 'Key already exists'

@app.route('/get_val', methods=['GET'])
@cache.cached(timeout=300, key_prefix='get_cache')
def get_val():
    employee_Id = request.headers.get('Employee_Id')
    
    conn = dbconnect()
    cursor = conn.cursor()
    if employee_Id is None:
        cursor.execute('SELECT Employee_Name, Employee_Id FROM data')
    else:
        cursor.execute('SELECT Employee_Name, Employee_Id FROM data WHERE Employee_Id = ?', (employee_Id,))
    result = cursor.fetchall()
    data_dict = {key: value for key, value in result}
    return data_dict

if __name__ == '__main__':
    app.run(port=8003)