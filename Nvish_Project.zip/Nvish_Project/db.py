import sqlite3
from sqlalchemy import create_engine
def dbconnect():
    conn = sqlite3.connect('data.db')
    cursor = conn.cursor()
    cursor.execute('CREATE TABLE IF NOT EXISTS data (Employee_Name TEXT PRIMARY KEY, Employee_Id TEXT)')
    conn.commit()
    return conn

