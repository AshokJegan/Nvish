import json
from exercise_1 import app, get_ping

def test_ping():
    with app.app_context():
        response = get_ping()
        data = json.loads(response.data)
        assert "message" in data
        assert data["message"] == "Ping"
