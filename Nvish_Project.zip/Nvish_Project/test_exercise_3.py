from exercise_3 import app, save_data, get_data, delete_data, get_all_data
from unittest.mock import patch

@patch('exercise_3.request', app.test_request_context(
        json={'Employee_Name': 'Jegan15', 'Employee_Id': '15'}).request)      
def test_save_data():
    with app.app_context():
        response = save_data()
        assert response == 'Data saved successfully'

@patch('exercise_3.request', app.test_request_context(
        headers={'Employee_Id': '15'}).request)      
def test_get_data():
    with app.app_context():
        response = get_data()
        assert response == {'Jegan15': '15'}

def test_get_all_data():
    with app.app_context():
        response = get_all_data()
        assert response is not None

@patch('exercise_3.request', app.test_request_context(
        query_string={'Employee_Id': '15'}).request)      
def test_delete_data():
    with app.app_context():
        response = delete_data()
        assert response == 'Data deleted successfully'
