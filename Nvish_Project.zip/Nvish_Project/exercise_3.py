from flask import Flask, request
from db import dbconnect
import sqlite3

app= Flask(__name__)

@app.route('/save', methods=['POST'])
def save_data():
    data = request.json
    key = data.get('Employee_Name')
    value = data.get('Employee_Id')
    if key is None or value is None:
        return 'Both key and value are required'
    try:        
        conn = dbconnect()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO data (Employee_Name, Employee_Id) VALUES (?, ?)', (key, value))
        conn.commit()
        return 'Data saved successfully'
    except sqlite3.IntegrityError:
         return 'Key already exists'

@app.route('/get_data', methods=['GET'])
def get_data():
    employee_Id = request.headers.get('Employee_Id') 
    conn = dbconnect()
    cursor = conn.cursor()
    cursor.execute('SELECT Employee_Name, Employee_Id FROM data WHERE Employee_Id = ?', (employee_Id,))
    result = cursor.fetchall()
    data_dict = {key: value for key, value in result}
    return data_dict

@app.route('/get_all_data', methods=['GET'])
def get_all_data():
    conn = dbconnect()
    cursor = conn.cursor()
    cursor.execute('SELECT Employee_Name, Employee_Id FROM data')
    result = cursor.fetchall()
    data_dict = {key: value for key, value in result}
    return data_dict

@app.route('/delete', methods=['DELETE'])
def delete_data():
    employee_Id = request.args.get('Employee_Id')

    if employee_Id is None:
        return 'Key parameter is required'
    
    conn = dbconnect()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM data WHERE Employee_Id = ?', (employee_Id,))
    conn.commit()
    return 'Data deleted successfully'

if __name__ == '__main__':
    app.run(port=8002)