from flask import Flask, request

app = Flask(__name__)
pre_shared_key = "allow"

def authorize_request():
    auth_header = request.headers.get('Authorization')
    if not auth_header:
        return False
    
    entered_key = auth_header.split()[-1]
    return pre_shared_key == entered_key

@app.route('/authorize', methods=['POST'])
def authorize():
    if authorize_request():
        return 'Authorization Successful'
    else:
        return 'Authorization Failed'
    
if __name__ == '__main__':
    app.run(port=8001)
