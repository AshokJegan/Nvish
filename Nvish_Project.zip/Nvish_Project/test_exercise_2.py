from exercise_2 import app, authorize
from unittest.mock import patch

@patch('exercise_2.request', app.test_request_context(headers={'Authorization': 'allow'}).request)      
def test_authorize_pass():  
    with app.app_context():
        response = authorize()
        assert response == 'Authorization Successful'

@patch('exercise_2.request', app.test_request_context(headers={'Authorization': 'Bearer'}).request)      
def test_authorize_fail():
    with app.app_context():
        response = authorize()
        assert response == 'Authorization Failed'
